<?php 

require("./fpdf.php");
// เชื่อมต่อกับฐานข้อมูล
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_item";

$conn = new mysqli($servername, $username, $password, $dbname);

// ตรวจสอบการเชื่อมต่อ
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// รับค่า id_request จาก URL
$id_request = $_GET['id'];

// ดึงข้อมูลจากตาราง db_item
$sql = "SELECT * FROM item_borrowreturn WHERE id = $id_request";
$result = $conn->query($sql);

// ตรวจสอบว่าการคิวรีสำเร็จหรือไม่
if ($result === false) {
    die("Error: " . $conn->error);
}

if ($result->num_rows > 0) {
    // สร้างวัตถุ FPDF


$pdf = new FPDF();
$pdf->AddPage('P', 'A4'); 
$pdf -> AddFont('THSarabunNew','B','THSarabunNew.php');
$pdf -> SetFont('THSarabunNew','B',18);




$pdf->Cell( 0  , 6 , iconv( 'UTF-8','cp874' ,'ที่ สข oo๓๓.๑o๑.๒/' ) , 0 , 1 ,'');
$pdf->Cell( 0  , 6 , iconv( 'UTF-8','cp874' ,'โรงพยาบาลหาดใหญ่' ) , 0 , 1 , 'R' );
$pdf->Cell( 0  , 6 , iconv( 'UTF-8','cp874' , '๑๘๒ ถนนรัถการ อำเภอหาดใหญ่' ) , 0 , 1 , 'R' );
$pdf->Cell( 0  , 6 , iconv( 'UTF-8','cp874' , 'จังหวัดสงขลา   ๙o๑๑o' ) , 0 , 1 , 'R' );

$imagePath = 'logo.jpg'; 
$pdf->Image($imagePath, 90, 10, 30); // (ไฟล์, X, Y, ความกว้าง)


$pdf->Ln(20);


// เพิ่มหัวข้อ

$pdf -> AddFont('THSarabunNew','B','THSarabunNew.php');

$pdf -> SetFont('THSarabunNew','B',18);



// $imagePath = './img/digital.png'; 
// $pdf->Image($imagePath, 1,1,210,297); // (ไฟล์, X, Y, ความกว้าง)

    // แสดงข้อมูล
    while($row = $result->fetch_assoc()) {
        // ตรวจสอบว่าคีย์มีอยู่ในผลลัพธ์หรือไม่
        $emp_name = isset($row["emp_name"]) ? $row["emp_name"] : 'emp_name';
        $department = isset($row["department"]) ? $row["department"] : 'N/A';
        $position = isset($row["position"]) ? $row["position"] : 'N/A';
        $price = isset($row["price"]) ? $row["price"] : 'N/A';

        // เพิ่มข้อมูลลงใน PDF
        $pdf->Cell(0, 6, iconv('UTF-8','cp874', '        หนังสือฉบับนี้ให้ไว้เพื่อรับรองว่า (นาย/นาง/นางสาว) '), 0, 1,$emp_name) ;
        $pdf->Cell(0, 6, iconv('UTF-8','cp874', 'แผนก: ' . $department), 0, 1, '');
        $pdf->Cell(0, 6, iconv('UTF-8','cp874', 'ตำแหน่ง: ' . $position), 0, 1, '');
        $pdf->Cell(0, 6, iconv('UTF-8','cp874', 'ราคา: ' . $price), 0, 1, '');
    }

// $pdf->Cell( 0  , 6 , iconv( 'UTF-8','cp874' , '                 หนังสือฉบับนี้ให้ไว้เพื่อรับรองว่า (นาย/นาง/นางสาว) ........................................................................') , 0 , 1 );
// $pdf->Cell( 0  , 15 , iconv( 'UTF-8','cp874' , 'เป็น (ข้าราชการพลเรือน / พนักงานราชการ / พนักงานกระทรวงสาธารณสุข / ลูกจ้างชั่วคราวรายเดือน / ลูกจ้าง' ) , 0 , 1 );
// $pdf->Cell( 0  , 6, iconv( 'UTF-8','cp874' , 'ประจำ / ลูกจ้างชั่วคราวรายวัน / พนักงานจ้างเหมาบริการ / อื่น............................................................................) ' ) , 0 , 1 );
// $pdf->Cell( 0  , 15 , iconv( 'UTF-8','cp874' , 'ตำแหน่ง....................................กลุ่มงาน................................................ตั้งแต่วันที่.................................................... ' ) , 0 , 1 );
// $pdf->Cell( 0  , 6 , iconv( 'UTF-8','cp874' , ' ได้รับเงินเดือน / ค่าจ้างเดือนละ / วันละ........................................บาทและปัจจุบันยังคงปฏิบัติงานที่โรงพยาบาล' ) , 0 , 1 );
// $pdf->Cell( 0  , 16 , iconv( 'UTF-8','cp874' , 'หาดใหญ่ สำนักงานสาธารณสุขจังหวัดสงขลา  จริง' ) , 0 , 1 );
// $pdf->Cell( 0  , 5 , iconv( 'UTF-8','cp874' , '                ให้ไว้ ณ วันที่.......................................................' ) , 0 , 1 );
 
$pdf->Ln(25);
$pdf->Cell( 0  , 5 , iconv( 'UTF-8','cp874' , '                (จ่าเอกชำนาญ   ชูรัตน์)' ) , 0 , 1 , 'C', );
$pdf->Cell( 0  , 10 , iconv( 'UTF-8','cp874' , '                รองผู้อำนวยการฝ่ายบริหาร' ) , 0 , 1 , 'C', );
$pdf->Cell( 0  , 5 , iconv( 'UTF-8','cp874' , '                ปฏิบัติราชการแทนผู้อำนวยการโรงพยาบาลหาดใหญ่' ) , 0 , 1 , 'C', );

$pdf->Ln(30);
$pdf -> AddFont('THSarabunNew_b','B','THSarabunNew_b.php');
$pdf -> SetFont('THSarabunNew_b','B',18);
$pdf->Cell( 0  , 5 , iconv( 'UTF-8','cp874' , '         รายได้อื่นนอกเหนือจากเงินเดือน (ถ้ามี)' ) , 0 , 1 );


$pdf -> AddFont('THSarabunNew','B','THSarabunNew.php');
$pdf -> SetFont('THSarabunNew','B',18);
$pdf->Cell( 0  , 20 , iconv( 'UTF-8','cp874' , '         เงินประจำตำแหน่ง และค่าตอบแทน' ) , 0 , 1 );
$pdf->Cell( 0  , 0 , iconv( 'UTF-8','cp874' , '         ค่าตอบแทน พ.ต.ส.' ) , 0 , 1 );
$pdf->Cell( 0  , 20 , iconv( 'UTF-8','cp874' , '         ค่าตอบแทนไม่ทำเวชปฏิบัติ' ) , 0 , 1 );
$pdf->Cell( 0  , 0 , iconv( 'UTF-8','cp874' , '         ค่าตอบแทนปฏิบัติงาน P๔P' ) , 0 , 1 );
$pdf->Cell( 0  , 20 , iconv( 'UTF-8','cp874' , '         ค่าตอบแทนนอกเวลาราชการ' ) , 0 , 1 );
$pdf->Cell( 0  , 0 , iconv( 'UTF-8','cp874' , '         ค่าตอบแทน ฉ.๑๑' ) , 0 , 1 );

$pdf->Output();
} else {
    echo "0 results";
}

$conn->close();
?>


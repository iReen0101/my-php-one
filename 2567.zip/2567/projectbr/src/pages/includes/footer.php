<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <!-- <b>Version</b> 3.0.0-alpha -->
    </div>
    <strong><center>Copyright &copy; 2020 All rights reserved.</center></strong>
</footer>
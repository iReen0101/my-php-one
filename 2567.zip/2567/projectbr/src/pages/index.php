<?php 
    header('Location: dashboard');
?>